// ── UI refs ──
const runBtn       = document.getElementById('runBtn');
const stopBtn      = document.getElementById('stopBtn');
const statusText   = document.getElementById('statusText');
const progressWrap = document.getElementById('progressWrap');
const progressBar  = document.getElementById('progressBar');
const logBox       = document.getElementById('logBox');
const notePreview  = document.getElementById('notePreview');
const noteText     = document.getElementById('noteText');

function setStatus(msg, type = 'idle') {
  statusText.className = `status-text ${type}`;
  statusText.innerHTML = type === 'running' ? `<span class="spinner"></span>${msg}` : msg;
}
function addLog(msg, type = '') {
  logBox.style.display = 'block';
  const line = document.createElement('div');
  line.className = `log-line ${type}`;
  line.textContent = `› ${msg}`;
  logBox.appendChild(line);
  logBox.scrollTop = logBox.scrollHeight;
}
function setProgress(pct) {
  progressWrap.style.display = 'block';
  progressBar.style.width = `${pct}%`;
}
function setPill(key, state) {
  const pill = document.getElementById(`pill-${key}`);
  if (pill) pill.className = `section-pill ${state}`;
}
function resetPills() {
  ['disclosure','malpractice','profhistory'].forEach(k => setPill(k,'pending'));
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'LOG')          addLog(msg.text, msg.level || '');
  if (msg.type === 'STATUS')       setStatus(msg.text, msg.level || 'running');
  if (msg.type === 'PROGRESS')     setProgress(msg.pct);
  if (msg.type === 'PILL')         setPill(msg.key, msg.state);
  if (msg.type === 'NOTE_PREVIEW') { notePreview.style.display = 'block'; noteText.textContent = msg.text; }
  if (msg.type === 'DONE')  { runBtn.disabled = false; stopBtn.style.display = 'none'; setStatus('✅ Done! Note written in Notes tab.', 'done'); setProgress(100); }
  if (msg.type === 'ERROR') { runBtn.disabled = false; stopBtn.style.display = 'none'; setStatus(`❌ ${msg.text}`, 'error'); addLog(msg.text, 'err'); }
});

runBtn.addEventListener('click', async () => {
  runBtn.disabled = true;
  stopBtn.style.display = 'block';
  logBox.innerHTML = '';
  logBox.style.display = 'none';
  notePreview.style.display = 'none';
  resetPills();
  setStatus('Starting...', 'running');
  setProgress(5);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({ target: { tabId: tab.id }, func: startAutomation });
});

stopBtn.addEventListener('click', async () => {
  runBtn.disabled = false;
  stopBtn.style.display = 'none';
  setStatus('Stopped by user.', 'idle');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => { window.__medStop = true; } });
});

function startAutomation() {
  window.__medStop = false;
  const send  = (type, payload = {}) => chrome.runtime.sendMessage({ type, ...payload });
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ── Get the correct document (main or iframe) ──
  function getDoc() {
    // Medallion runs inside an iframe — find it
    const iframes = Array.from(document.querySelectorAll('iframe'));
    for (const f of iframes) {
      try {
        const doc = f.contentDocument || f.contentWindow?.document;
        if (doc && doc.body && doc.body.innerText.length > 100) {
          return doc;
        }
      } catch(e) {}
    }
    return document; // fallback to main document
  }

  // ── 4 sections ──
  const SECTIONS = [
    { key: 'disclosure',  sidebarText: 'Disclosure Questions', comment: 'Updated Disclosure information to Match Verification.' },
    { key: 'malpractice', sidebarText: 'Malpractice Insurance', comment: 'Updated malpractice information to match facesheet.' },
    { key: 'profhistory', sidebarText: 'Professional History',  comment: 'Updated professional history information to match verification.' },
    { key: 'profinfo',    sidebarText: 'Professional Info',     comment: 'Updated Professional Info to match verification.' },
  ];

  function isMedallionStaff(name) {
    if (!name) return false;
    if (name.includes('@')) return false;
    if (/^user\b/i.test(name)) return false;
    if (/^medallion\b/i.test(name)) return false;
    return true;
  }

  // ── Find the "Updated on" button for a given section heading text ──
  // Structure: <h2 class="ant-typography">Section Name <span><button class="provider-section-history-link"><span>Updated on...</span></button></span></h2>
  function findHistoryButton(sidebarText) {
    // Method 1: Find by class name directly — most reliable
    const historyBtns = Array.from(getDoc().querySelectorAll('button.provider-section-history-link, button[class*="provider-section-history"]'));
    send('LOG', { text: `History buttons found on page: ${historyBtns.length}` });

    for (const btn of historyBtns) {
      // Walk up to find the h2 that contains this button
      let node = btn.parentElement;
      for (let i = 0; i < 5; i++) {
        if (!node) break;
        if (/^H[1-6]$/.test(node.tagName)) {
          // Get heading text without the button text
          const headingText = node.textContent.replace(/updated on.*/i, '').trim().toLowerCase();
          const keyword = sidebarText.toLowerCase().split(' ')[0];
          if (headingText.includes(keyword)) {
            send('LOG', { text: `Matched button to section: "${sidebarText}"`, level: 'ok' });
            return btn;
          }
        }
        node = node.parentElement;
      }
    }

    // Method 2: Find h2 with ant-typography class containing the section name, then find button inside
    const allH2 = Array.from(getDoc().querySelectorAll('h2.ant-typography, h1.ant-typography, h3.ant-typography'));
    for (const h2 of allH2) {
      const h2Text = h2.textContent.replace(/updated on.*/i, '').trim().toLowerCase();
      const keyword = sidebarText.toLowerCase().split(' ')[0];
      if (h2Text.includes(keyword)) {
        const btn = h2.querySelector('button');
        if (btn) {
          send('LOG', { text: `Found via h2 heading: "${sidebarText}"`, level: 'ok' });
          return btn;
        }
      }
    }

    return null;
  }

  // ── Click sidebar section ──
  async function clickSidebarSection(sidebarText) {
    const allEls = Array.from(getDoc().querySelectorAll('a, button, li, [class*="sidebar"] *, [class*="nav"] *, [class*="menu"] *'));
    const match = allEls.find(el => {
      const t = el.textContent.trim();
      return t === sidebarText || t.startsWith(sidebarText);
    });
    if (!match) { send('LOG', { text: `Sidebar not found: "${sidebarText}"`, level: 'warn' }); return false; }
    match.click();
    send('LOG', { text: `Clicked sidebar: "${sidebarText}"` });
    await sleep(1500);
    return true;
  }

  // ── Open Edit History modal by clicking the button ──
  async function openHistoryModal(btn) {
    btn.click();
    for (let i = 0; i < 60; i++) {
      await sleep(250);
      for (const d of getDoc().querySelectorAll('[role="dialog"]')) {
        if (!d.offsetParent) continue;
        const txt = d.innerText || '';
        if (
          /edit history/i.test(txt) ||
          /answer given/i.test(txt) ||
          (/\d{2}\/\d{2}\/\d{4}/.test(txt) && txt.length > 50)
        ) return d;
      }
    }
    return null;
  }

  // ── Close Edit History modal ──
  async function closeHistoryModal(modal) {
    if (!modal) return;
    const allBtns = Array.from(modal.querySelectorAll('button'));
    const closeBtn = allBtns.find(b => /^close$/i.test(b.textContent.trim())) || allBtns[allBtns.length - 1];
    if (closeBtn) { closeBtn.click(); await sleep(700); return; }
    getDoc().dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    await sleep(700);
  }

  // ── Check if any real staff (no @) updated ──
  function hasStaffUpdate(modal) {
    const txt = modal.innerText || '';

    // Empty modal = no updates at all → skip
    const meaningful = txt.replace(/edit history|close/gi, '').trim();
    if (meaningful.length < 20) {
      send('LOG', { text: 'Modal is empty — no updates.' });
      return false;
    }

    const lines = txt.split('\n').map(l => l.trim()).filter(Boolean);
    const updaters = [];
    for (const line of lines) {
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(line))       continue; // date
      if (/^\d{1,2}:\d{2}\s*(am|pm)$/i.test(line))  continue; // time
      if (/^answer given:/i.test(line))               continue;
      if (/^disclosure question:/i.test(line))        continue;
      if (/^edit history/i.test(line))                continue;
      if (/^close$/i.test(line))                      continue;
      if (line.length > 150)                          continue; // long question text

      // Capture lines that look like a name or email
      if (
        line.includes('@') ||                          // email/bot
        /^user\b/i.test(line) ||                      // "User added/made..."
        /^[A-Z][a-z]+ [A-Z][a-z]+/.test(line)         // "First Last" real name
      ) {
        updaters.push(line.split(/\s{2,}|\t/)[0].trim());
      }
    }

    send('LOG', { text: `Updaters detected: ${updaters.join(' | ') || 'none'}` });
    return updaters.some(u => isMedallionStaff(u));
  }

  // ── Write private note (original working logic) ──
  async function writePrivateNote(noteContent) {
    send('LOG', { text: 'Going to Notes tab...', level: 'ok' });

    const notesTab = Array.from(getDoc().querySelectorAll('a, button, [role="tab"]'))
      .find(el => el.textContent.trim().toLowerCase() === 'notes');
    if (!notesTab) { send('LOG', { text: 'Notes tab not found.', level: 'err' }); return false; }

    notesTab.click();
    await sleep(2000);

    const addNoteBtn = Array.from(getDoc().querySelectorAll('button, a, [role="button"]'))
      .find(el => el.textContent.trim().toLowerCase() === 'add note');
    if (!addNoteBtn) { send('LOG', { text: '"Add Note" not found.', level: 'err' }); return false; }

    send('LOG', { text: 'Clicking Add Note...', level: 'ok' });
    addNoteBtn.click();
    await sleep(1500);

    // Close Add Task if accidentally opened
    for (const d of Array.from(getDoc().querySelectorAll('[role="dialog"]')).filter(d => d.offsetParent)) {
      if (/add task/i.test(d.innerText)) {
        send('LOG', { text: 'Add Task opened — closing.', level: 'warn' });
        const cancelBtn = Array.from(d.querySelectorAll('button')).find(b => /cancel/i.test(b.textContent));
        if (cancelBtn) cancelBtn.click();
        else getDoc().dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
        await sleep(800);
        break;
      }
    }

    // Find Notes dialog
    let noteDialog = null;
    for (let attempt = 0; attempt < 15; attempt++) {
      await sleep(300);
      const openDlgs = Array.from(getDoc().querySelectorAll('[role="dialog"]')).filter(d => d.offsetParent);
      noteDialog = openDlgs.find(d =>
        !/add task/i.test(d.innerText) &&
        (
          d.querySelector('[placeholder="Note"]') ||
          /public note|private note/i.test(d.innerText) ||
          (d.querySelector('textarea') && !/task title/i.test(d.innerText)) ||
          d.querySelector('[contenteditable="true"]')
        )
      );
      if (noteDialog) break;
    }
    if (!noteDialog) { send('LOG', { text: 'Notes dialog not found.', level: 'err' }); return false; }

    // Type note
    const noteInput =
      noteDialog.querySelector('[placeholder="Note"]') ||
      noteDialog.querySelector('[contenteditable="true"]') ||
      noteDialog.querySelector('textarea');
    if (!noteInput) { send('LOG', { text: 'Note input not found.', level: 'err' }); return false; }

    noteInput.focus();
    await sleep(300);
    if (noteInput.isContentEditable) {
      noteInput.innerHTML = '';
      getDoc().execCommand('insertText', false, noteContent);
    } else {
      noteInput.value = noteContent;
      noteInput.dispatchEvent(new Event('input',  { bubbles: true }));
      noteInput.dispatchEvent(new Event('change', { bubbles: true }));
    }
    await sleep(400);
    send('LOG', { text: 'Note text typed.', level: 'ok' });

    // Set Private
    if (/public note/i.test(noteDialog.innerText || '')) {
      const toggle =
        noteDialog.querySelector('[role="switch"]') ||
        noteDialog.querySelector('input[type="checkbox"]') ||
        noteDialog.querySelector('[class*="toggle"]') ||
        noteDialog.querySelector('[class*="switch"]');
      if (toggle) { toggle.click(); await sleep(400); send('LOG', { text: 'Set to Private.', level: 'ok' }); }
      else {
        for (const btn of noteDialog.querySelectorAll('button')) {
          if (/public/i.test(btn.closest('div,span,label')?.innerText || '')) {
            btn.click(); await sleep(400);
            send('LOG', { text: 'Toggled to Private.', level: 'ok' });
            break;
          }
        }
      }
    } else {
      send('LOG', { text: 'Already Private.', level: 'ok' });
    }

    await sleep(400);

    // Post / Save
    const postBtn = Array.from(noteDialog.querySelectorAll('button')).find(b => {
      const t = b.textContent.trim().toLowerCase();
      return (t === 'post' || t === 'save' || t === 'add note') && !b.disabled;
    });
    if (postBtn) {
      postBtn.click();
      send('LOG', { text: '✅ Note posted as Private!', level: 'ok' });
      await sleep(1000);
      return true;
    }
    send('LOG', { text: 'Post button not found — please click manually.', level: 'warn' });
    return false;
  }

  // ════════════════ MAIN ════════════════
  (async () => {
    try {
      send('STATUS', { text: 'Checking all 4 sections...', level: 'running' });
      send('PROGRESS', { pct: 5 });

      const notesToWrite = [];
      const total = SECTIONS.length;

      for (let i = 0; i < total; i++) {
        if (window.__medStop) { send('STATUS', { text: 'Stopped.', level: 'idle' }); return; }

        const sec = SECTIONS[i];
        send('PILL', { key: sec.key, state: 'scanning' });
        send('STATUS', { text: `Navigating to: ${sec.sidebarText} (${i+1}/${total})`, level: 'running' });

        // Step 1: Click sidebar
        const clicked = await clickSidebarSection(sec.sidebarText);
        if (!clicked) {
          send('PILL', { key: sec.key, state: 'not-found' });
          send('PROGRESS', { pct: 5 + Math.round((i+1)/total*55) });
          continue;
        }

        // Step 2: Find the history button (button.provider-section-history-link inside h2)
        const historyBtn = findHistoryButton(sec.sidebarText);
        if (!historyBtn) {
          send('LOG', { text: `No history button found in ${sec.sidebarText} — section may not have been updated yet.`, level: 'warn' });
          send('PILL', { key: sec.key, state: 'skipped' });
          send('PROGRESS', { pct: 5 + Math.round((i+1)/total*55) });
          continue;
        }

        send('LOG', { text: `Found history button for ${sec.sidebarText} — clicking...` });

        // Step 3: Open modal
        const modal = await openHistoryModal(historyBtn);
        if (!modal) {
          send('LOG', { text: `Modal did not open for ${sec.sidebarText} — skipping.`, level: 'warn' });
          send('PILL', { key: sec.key, state: 'skipped' });
          send('PROGRESS', { pct: 5 + Math.round((i+1)/total*55) });
          continue;
        }

        await sleep(400);

        // Step 4: Check for staff update
        const staffUpdated = hasStaffUpdate(modal);
        if (staffUpdated) {
          send('LOG', { text: `✅ Staff update in ${sec.sidebarText} → adding note.`, level: 'ok' });
          notesToWrite.push(sec.comment);
          send('PILL', { key: sec.key, state: 'noted' });
        } else {
          send('LOG', { text: `⏭ Only bot/provider updates in ${sec.sidebarText} → skipping.`, level: 'warn' });
          send('PILL', { key: sec.key, state: 'skipped' });
        }

        await closeHistoryModal(modal);
        await sleep(600);
        send('PROGRESS', { pct: 5 + Math.round((i+1)/total*55) });
      }

      // Step 5: Write all notes
      if (!notesToWrite.length) {
        send('STATUS', { text: '✅ Done — no staff updates found. No notes needed.', level: 'done' });
        send('PROGRESS', { pct: 100 });
        send('DONE', {});
        return;
      }

      const finalNote = notesToWrite.join('\n');
      send('NOTE_PREVIEW', { text: finalNote });
      send('LOG', { text: `Writing ${notesToWrite.length} note(s) to Notes tab...`, level: 'ok' });
      send('PROGRESS', { pct: 65 });

      const success = await writePrivateNote(finalNote);
      send('PROGRESS', { pct: 100 });

      if (success) {
        send('DONE', {});
      } else {
        send('STATUS', { text: '⚠️ Could not auto-save — copy note from green box above.', level: 'error' });
        send('NOTE_PREVIEW', { text: finalNote });
      }

    } catch (err) {
      send('ERROR', { text: err.message || 'Unknown error.' });
    }
  })();
}
